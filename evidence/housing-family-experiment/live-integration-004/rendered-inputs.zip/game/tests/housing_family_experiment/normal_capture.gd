extends "res://game/tests/rendered_visual_evidence_capture.gd"
const FAMILY = preload("res://game/scripts/world/facades/housing_site_family.gd")
var output := ""
var rows: Array = []

func _initialize() -> void:
	create_timer(480.0,true,false,true).timeout.connect(func(): _fail("Experiment timeout"); _receipt(); quit(1))
	call_deferred("_run")

func _run() -> void:
	var manifest_path := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--manifest="): manifest_path = arg.trim_prefix("--manifest=")
		if arg.begins_with("--output="): output = arg.trim_prefix("--output=")
	if not _require(not output.is_empty() and not DirAccess.dir_exists_absolute(output), "Fresh output required"):
		await _finish(null)
		return
	DirAccess.make_dir_recursive_absolute(output)
	var manifest: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(manifest_path))
	var main := (load("res://game/scenes/main.tscn") as PackedScene).instantiate() as GameMain
	var world := main.get_node("WorldRoot") as WorldLoader
	var player := main.get_node("Player") as PlayerController
	var ready: Array = []
	var errors: Array = []
	world.world_ready.connect(func(r: Dictionary): ready.append(r))
	world.world_failed.connect(func(c: String,m: String,k: Array): errors.append([c,m,k]))
	root.add_child(main)
	var begin := Time.get_ticks_msec()
	while ready.is_empty() and errors.is_empty() and Time.get_ticks_msec()-begin < 45000: await process_frame
	await physics_frame
	await physics_frame
	if not _require(errors.is_empty() and ready.size()==1 and world.is_world_validated(), "Source world load: %s" % [errors]):
		_receipt()
		await _finish(main)
		return
	(main.get_node("Interface/HUD") as GameHUD).hide()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	for target: Dictionary in manifest.targets:
		var row: Dictionary = target.duplicate(true)
		row.requested_xz=Vector2(target.requested_xz[0],target.requested_xz[1])
		row.aim_target=FAMILY.vec(target.aim_target)
		var settled := await _settle_player(row.requested_xz,row.id,world,player)
		if not _require(settled.get("ok",false),str(settled)): break
		_aim_camera_at(player,row.aim_target)
		if not await _wait_for_render(player): break
		row.id=target.id+"-LIVE"
		var saved := _save_current_view(row,output,player,{"phase":"LIVE","source_key":target.source_key,"scope":"Normal WorldLoader family integration"})
		if not _require(saved.get("ok",false),str(saved)): break
		rows.append(saved.metadata)
		_receipt()
	if rows.size()!=manifest.targets.size(): _fail("Incomplete normal-play captures")
	if not _verify_family(world):
		_receipt()
		await _finish(main)
		return
	# Representative stock input motion in the settled final street view.
	var motion_start := player.global_position
	Input.action_press("move_forward")
	for frame in 30: await physics_frame
	Input.action_release("move_forward")
	for frame in 30: await physics_frame
	var walked := player.global_position.distance_to(motion_start)
	if not _require(walked>0.3 and walked<4.0,"Representative stock walk displacement "+str(walked)):
		_receipt()
		await _finish(main)
		return
	print("FAMILY_STOCK_WALK distance=",walked," grounded=",player.is_on_floor()," velocity=",player.velocity)
	if not await _stock_family_spray(world,player):
		_receipt()
		await _finish(main)
		return
	# Lifecycle proof uses the real loader, not a second attachment call.
	world.load_world()
	await physics_frame
	await physics_frame
	_verify_family(world)
	_receipt()
	await _finish(main)

func _verify_family(world: WorldLoader) -> bool:
	var found: Dictionary = {}
	var sampled := 0
	for node: Node in world.find_children("SharedHousing_*","Node3D",true,false):
		var source := str(node.get_meta("source_key",""))
		if not _require(not found.has(source),"Duplicate live instance "+source): return false
		found[source]=true
		var bodies := 0
		var mesh_samples := 0
		var tiny_meshes := 0
		for child: Node in node.get_children():
			if child is StaticBody3D:
				bodies+=1
				var wall := str(child.get_meta("family_role",""))=="wall"
				if not _require(child.collision_layer==(5 if wall else 1) and child.is_in_group("spray_receiver_wall")==wall,"Family collision/spray role "+source): return false
			elif child is MeshInstance3D:
				var mesh := child as MeshInstance3D
				var role := str(mesh.get_meta("family_role","support"))
				if not _require(mesh.layers==(2 if role=="wall" else 1),"Family render role "+source): return false
				var faces := mesh.mesh.get_faces()
				var selected := -1
				var largest_area := 0.0
				for candidate in range(0,faces.size(),3):
					var area := (faces[candidate+1]-faces[candidate]).cross(faces[candidate+2]-faces[candidate]).length()/2
					if area>largest_area: largest_area=area; selected=candidate
				if largest_area<0.0001:
					tiny_meshes+=1
					print("FAMILY_TINY_CONTACT_UNRESOLVED source=",source," mesh=",mesh.get_index()," max_triangle_area=",largest_area)
					continue
				for i in [selected]:
					var a := mesh.global_transform*faces[i]
					var b := mesh.global_transform*faces[i+1]
					var c := mesh.global_transform*faces[i+2]
					var normal := (b-a).cross(c-a).normalized()
					if normal.length()<0.5: continue
					var center := (a+b+c)/3
					var hit := world.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(center-normal*0.035,center+normal*0.035,1))
					if hit.is_empty(): hit=world.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(center+normal*0.035,center-normal*0.035,1))
					if not _require(not hit.is_empty() and (hit.position as Vector3).distance_to(center)<0.036 and source in hit.collider.get_meta("source_keys",[]),"Installed mesh contact missing %s role %s mesh %s triangle %s points %s %s %s area %s actual_hit %s" % [source,role,mesh.get_index(),i,a,b,c,(b-a).cross(c-a).length()/2,hit]): return false
					mesh_samples+=1
					break
		if not _require(bodies>=2 and mesh_samples>0,"Missing live body/mesh "+source): return false
		sampled+=mesh_samples
		print("FAMILY_LIVE_FIT source=",source," bodies=",bodies," mesh_contact_samples=",mesh_samples," tiny_meshes_not_ray_proved=",tiny_meshes)
	var topology := {"visible_meshes":0,"visible_surfaces":0,"visible_triangles":0,"active_bodies":0,"active_shapes":0,"disabled_bodies":0}
	for child: Node in world.find_children("*","Node3D",true,false):
		if child is MeshInstance3D and child.is_visible_in_tree():
			topology.visible_meshes+=1
			topology.visible_surfaces+=child.mesh.get_surface_count()
			topology.visible_triangles+=child.mesh.get_faces().size()/3
		elif child is StaticBody3D:
			if child.collision_layer==0: topology.disabled_bodies+=1
			else:
				topology.active_bodies+=1
				for shape: Node in child.get_children():
					if shape is CollisionShape3D and not shape.disabled: topology.active_shapes+=1
	print("FAMILY_CURRENT_TOPOLOGY ",JSON.stringify(topology))
	print("FAMILY_LIVE_TOTAL instances=",found.size()," mesh_contact_samples=",sampled)
	return _require(found.size()==24,"Expected24 normal-load instances")

func _receipt() -> void:
	if output.is_empty() or not DirAccess.dir_exists_absolute(output): return
	var file := FileAccess.open(output.path_join("capture-receipt.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"ok":_failure.is_empty(),"failure":_failure,"captures":rows,"scope":"Visual experiment, no acceptance or collision fit claim"},"\t")+"\n")

func _stock_family_spray(world: WorldLoader, player: PlayerController) -> bool:
	var models := world.find_children("SharedHousing_w96215646","Node3D",true,false)
	if not _require(models.size()==1,"1394 stock probe owner"): return false
	var target := Vector3.ZERO
	var outward := Vector3.ZERO
	for child: Node in models[0].get_children():
		if not child is MeshInstance3D or str(child.get_meta("family_role",""))!="wall": continue
		var faces: PackedVector3Array = child.mesh.get_faces()
		for i in range(0,faces.size(),3):
			var a: Vector3=child.global_transform*faces[i]
			var b: Vector3=child.global_transform*faces[i+1]
			var c: Vector3=child.global_transform*faces[i+2]
			var cross: Vector3=(b-a).cross(c-a)
			var center: Vector3=(a+b+c)/3
			if cross.length()>1.0 and center.y>4.0 and center.y<7.2 and (-cross.normalized()).x< -0.8:
				target=center
				outward=-cross.normalized()
				break
		if outward.length()>0.5: break
	if not _require(outward.length()>0.5,"Substantial west wall for stock spray"): return false
	var anchor := target+outward*2.0
	var ground := world.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(Vector3(anchor.x,30,anchor.z),Vector3(anchor.x,-10,anchor.z),1,[player.get_rid()]))
	if not _require(not ground.is_empty(),"Stock approach ground"): return false
	_clear_gameplay_input()
	player.set_gameplay_enabled(false)
	player.global_position=ground.position+Vector3.UP*0.35
	player.velocity=Vector3.ZERO
	player.set_gameplay_enabled(true)
	var recovery := world.get_runtime_evidence().recovery_count
	for frame in 90: await physics_frame
	if not _require(player.is_on_floor() and world.get_runtime_evidence().recovery_count==recovery,"Stock approach settled without recovery"): return false
	_aim_camera_at(player,target)
	if not await _wait_for_render(player): return false
	var hit := _camera_spray_hit(player)
	if not _require(not hit.is_empty() and str(hit.collider.get_meta("derived_object_key",""))=="building:w96215646:wall","Stock spray source first hit"): return false
	var controller := player.get_spray_controller()
	var before := controller.tag_instances.active_count()
	controller.attempt_spray()
	await process_frame
	if not _require(controller.tag_instances.active_count()==before+1,"Actual stock spray placement"): return false
	var saved := _save_current_view({"id":"1394-stock-spray","region":"w96215646","intent":"Actual stock spray/contact representative"},output,player,{"phase":"mechanics","source_key":"w96215646","scope":"Representative motion only; per-building ray coverage logged separately"})
	print("FAMILY_STOCK_SPRAY placed=1 source=w96215646 grounded=",player.is_on_floor()," target=",target," hit=",hit.position)
	return _require(saved.get("ok",false),"Stock spray image")
