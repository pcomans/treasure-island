extends "res://game/tests/rendered_visual_evidence_capture.gd"
const FAMILY = preload("res://game/scripts/world/facades/housing_site_family.gd")
var output := ""
var rows: Array = []

func _initialize() -> void:
	create_timer(480.0,true,false,true).timeout.connect(func(): _fail("Experiment timeout"); _receipt(); quit(1))
	call_deferred("_run")

func _run() -> void:
	var manifest_path := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--manifest="): manifest_path = arg.trim_prefix("--manifest=")
		if arg.begins_with("--output="): output = arg.trim_prefix("--output=")
	if not _require(not output.is_empty() and not DirAccess.dir_exists_absolute(output), "Fresh output required"):
		await _finish(null)
		return
	DirAccess.make_dir_recursive_absolute(output)
	var manifest: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(manifest_path))
	var main := (load("res://game/scenes/main.tscn") as PackedScene).instantiate() as GameMain
	var world := main.get_node("WorldRoot") as WorldLoader
	var player := main.get_node("Player") as PlayerController
	var ready: Array = []
	var errors: Array = []
	world.world_ready.connect(func(r: Dictionary): ready.append(r))
	world.world_failed.connect(func(c: String,m: String,k: Array): errors.append([c,m,k]))
	root.add_child(main)
	var begin := Time.get_ticks_msec()
	while ready.is_empty() and errors.is_empty() and Time.get_ticks_msec()-begin < 45000: await process_frame
	await physics_frame
	await physics_frame
	if not _require(errors.is_empty() and ready.size()==1 and world.is_world_validated(), "Source world load: %s" % [errors]):
		_receipt()
		await _finish(main)
		return
	(main.get_node("Interface/HUD") as GameHUD).hide()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if not _verify_family(world):
		_receipt()
		await _finish(main)
		return
	for target: Dictionary in manifest.targets:
		var row: Dictionary = target.duplicate(true)
		row.requested_xz=Vector2(target.requested_xz[0],target.requested_xz[1])
		row.aim_target=FAMILY.vec(target.aim_target)
		var settled := await _settle_player(row.requested_xz,row.id,world,player)
		if not _require(settled.get("ok",false),str(settled)): break
		_aim_camera_at(player,row.aim_target)
		if not await _wait_for_render(player): break
		row.id=target.id+"-LIVE"
		var saved := _save_current_view(row,output,player,{"phase":"LIVE","source_key":target.source_key,"scope":"Normal WorldLoader family integration"})
		if not _require(saved.get("ok",false),str(saved)): break
		rows.append(saved.metadata)
		_receipt()
	if rows.size()!=manifest.targets.size(): _fail("Incomplete normal-play captures")
	# Lifecycle proof uses the real loader, not a second attachment call.
	world.load_world()
	await physics_frame
	await physics_frame
	_verify_family(world)
	_receipt()
	await _finish(main)

func _verify_family(world: WorldLoader) -> bool:
	var found: Dictionary = {}
	var sampled := 0
	for node: Node in world.find_children("SharedHousing_*","Node3D",true,false):
		var source := str(node.get_meta("source_key",""))
		if not _require(not found.has(source),"Duplicate live instance "+source): return false
		found[source]=true
		var bodies := 0
		var mesh_samples := 0
		for child: Node in node.get_children():
			if child is StaticBody3D:
				bodies+=1
				var wall := str(child.get_meta("family_role",""))=="wall"
				if not _require(child.collision_layer==(5 if wall else 1) and child.is_in_group("spray_receiver_wall")==wall,"Family collision/spray role "+source): return false
			elif child is MeshInstance3D:
				var mesh := child as MeshInstance3D
				var role := str(mesh.get_meta("family_role","support"))
				if not _require(mesh.layers==(2 if role=="wall" else 1),"Family render role "+source): return false
				var faces := mesh.mesh.get_faces()
				for i in range(0,faces.size(),3):
					var a := mesh.global_transform*faces[i]
					var b := mesh.global_transform*faces[i+1]
					var c := mesh.global_transform*faces[i+2]
					var normal := (b-a).cross(c-a).normalized()
					if normal.length()<0.5: continue
					var center := (a+b+c)/3
					var hit := world.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(center-normal*0.035,center+normal*0.035,1))
					if hit.is_empty(): hit=world.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(center+normal*0.035,center-normal*0.035,1))
					if not _require(not hit.is_empty() and (hit.position as Vector3).distance_to(center)<0.036,"Installed mesh contact missing "+source+" role "+role): return false
					mesh_samples+=1
					break
		if not _require(bodies>=2 and mesh_samples>0,"Missing live body/mesh "+source): return false
		sampled+=mesh_samples
		print("FAMILY_LIVE_FIT source=",source," bodies=",bodies," mesh_contact_samples=",mesh_samples)
	print("FAMILY_LIVE_TOTAL instances=",found.size()," mesh_contact_samples=",sampled)
	return _require(found.size()==24,"Expected24 normal-load instances")

func _receipt() -> void:
	if output.is_empty() or not DirAccess.dir_exists_absolute(output): return
	var file := FileAccess.open(output.path_join("capture-receipt.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"ok":_failure.is_empty(),"failure":_failure,"captures":rows,"scope":"Visual experiment, no acceptance or collision fit claim"},"\t")+"\n")
